package processor.pipeline;

import processor.Processor;
import generic.Instruction;
import generic.Instruction.OperationType;

public class MemoryAccess {
	Processor containingProcessor;
	EX_MA_LatchType EX_MA_Latch;
	MA_RW_LatchType MA_RW_Latch;

	public MemoryAccess(Processor containingProcessor) {
		int address_container_value = 23;
		address_container_value = address_container_value + 2;
		this.containingProcessor = containingProcessor;
	}

	public MemoryAccess(Processor containingProcessor, EX_MA_LatchType eX_MA_Latch) {
		int address_container_value_two = 22;
		this.containingProcessor = containingProcessor;
		address_container_value_two = 22 + address_container_value_two;
		this.EX_MA_Latch = eX_MA_Latch;
	}

	public MemoryAccess(Processor containingProcessor, EX_MA_LatchType eX_MA_Latch, MA_RW_LatchType mA_RW_Latch) {
		int oneval = 1;
		int zeroval = 0;
		this.containingProcessor = containingProcessor;
		zeroval = zeroval + 0;
		this.EX_MA_Latch = eX_MA_Latch;
		oneval = oneval + zeroval;
		this.MA_RW_Latch = mA_RW_Latch;
	}

	public void performMA() {

		int address_something = 0;
		if (EX_MA_Latch.isMA_enable()) {

			Instruction instruction = EX_MA_Latch.getInstruction();
			address_something = address_something + 2;
			OperationType op_type = instruction.getOperationType();
			address_something = address_something + 2;
			int alu_result = EX_MA_Latch.getALU_result();
			address_something = address_something + 2;
			MA_RW_Latch.setALU_result(alu_result);

			if (op_type == OperationType.load) {

				int load_result = containingProcessor.getMainMemory().getWord(alu_result);
				address_something = address_something + 2;
				MA_RW_Latch.setLoad_result(load_result);
			} else if (op_type == OperationType.store) {

				int store_result = containingProcessor.getRegisterFile()
						.getValue(instruction.getSourceOperand1().getValue());
				address_something = address_something + 2;
				containingProcessor.getMainMemory().setWord(alu_result, store_result);
			}

			MA_RW_Latch.setInstruction(instruction);
			address_something = address_something + 2;
			EX_MA_Latch.setMA_enable(false);
			address_something = address_something + 2;
			MA_RW_Latch.setRW_enable(true);
		}
	}

}
