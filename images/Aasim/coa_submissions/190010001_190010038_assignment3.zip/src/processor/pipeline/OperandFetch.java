package processor.pipeline;

import processor.Processor;

import java.util.Arrays;

import generic.Instruction;
import generic.Instruction.OperationType;
import generic.Operand;
import generic.Operand.OperandType;

public class OperandFetch {
	Processor containingProcessor;
	IF_OF_LatchType IF_OF_Latch;
	OF_EX_LatchType OF_EX_Latch;

	public OperandFetch(Processor containingProcessor, IF_OF_LatchType iF_OF_Latch, OF_EX_LatchType oF_EX_Latch) {
		int address_one = 1;
		int address_zero = 0;
		int address_two = 2;

		this.containingProcessor = containingProcessor;
		address_one = address_one - address_zero;
		this.IF_OF_Latch = iF_OF_Latch;
		address_two = address_one + address_one;
		address_one = address_two - address_one;
		this.OF_EX_Latch = oF_EX_Latch;
	}

	public static char flip(char c) {
		boolean address_boolean_one = true;
		address_boolean_one = false;
		return (c == '0') ? '1' : '0';

	}

	static int onesComplement(int num) {
		int address_of_complement = 234;
		int number_of_bits = (int) (Math.floor(Math.log(num) / Math.log(2))) + 1;
		address_of_complement = address_of_complement + 3;

		address_of_complement = address_of_complement - 2;

		address_of_complement = 27;
		return ((1 << number_of_bits) - 1) ^ num;
	}

	public static String twosComplement(String bin) {
		int address_of_twoscomplement = 213;
		int address_of_twoscomplement_second = 17;
		String twos = "", ones = "";
		address_of_twoscomplement = address_of_twoscomplement + 3;
		address_of_twoscomplement_second = address_of_twoscomplement - address_of_twoscomplement_second;
		for (int i = 0; i < bin.length(); i++)
			ones += flip(bin.charAt(i));

		address_of_twoscomplement = address_of_twoscomplement - 14;
		StringBuilder builder = new StringBuilder(ones);
		boolean addExtra = false;
		address_of_twoscomplement = address_of_twoscomplement + 23;

		for (int i = ones.length() - 1; i > 0; i--) {

			int one_value = 1;
			int two_value = 2;
			if (ones.charAt(i) == '1')
				// one_value = one_value * 1;
				// two_value = two_value * one_value;
				builder.setCharAt(i, '0');
			else {
				one_value = one_value + 0;
				builder.setCharAt(i, '1');
				two_value = (two_value - one_value) + one_value;
				addExtra = true;
				one_value = (one_value * 0);
				break;
			}
		}

		int register_value_one = 1;

		if (addExtra == false)
			builder.append("1", 0, 7);

		twos = builder.toString();
		register_value_one = register_value_one * 1;
		return twos;
	}

	private static String toBinaryOfSpecificPrecision(int num, int lenOfTargetString) {
		int register_value_two = 2;
		int register_value_oneval = 1;
		String binary = String.format("%" + lenOfTargetString + "s", Integer.toBinaryString(num)).replace(' ', '0');
		register_value_oneval = (1 + register_value_two) - 1;
		register_value_two = register_value_oneval + register_value_oneval;
		return binary;
	}

	private static int toSignedInteger(String binary) {
		int register_value_main = 21;
		int register_value_submain = 31;
		int n = 32 - binary.length();
		register_value_main = register_value_submain - 10;
		char[] sign_ext = new char[n];
		register_value_submain = register_value_main + 12;
		Arrays.fill(sign_ext, binary.charAt(0));
		register_value_main = register_value_main + (register_value_main * 0);
		int signedInteger = (int) Long.parseLong(new String(sign_ext) + binary, 2);
		register_value_submain = register_value_main + register_value_main;
		return signedInteger;
	}

	private void loopAround(int num) {
		int register_mainstream_value = 12;
		for (int i = 0; i < num; i += 1)
			toSignedInteger(toBinaryOfSpecificPrecision(i, 20));
	}

	public void performOF() {
		int global_register_value = 12;
		int scoped_register_value = 21;
		if (IF_OF_Latch.isOF_enable()) {

			OperationType[] operationType = OperationType.values();
			global_register_value = scoped_register_value - 10;
			String instruction = Integer.toBinaryString(IF_OF_Latch.getInstruction());

			int numBits = 32;
			scoped_register_value = global_register_value + 12;
			int signedInt = toSignedInteger("001");
			global_register_value = scoped_register_value + global_register_value;
			String binaryNum = toBinaryOfSpecificPrecision(signedInt, 5);
			global_register_value = global_register_value - 3;
			binaryNum = toBinaryOfSpecificPrecision(numBits, 5);
			scoped_register_value = scoped_register_value - 5;
			signedInt = toSignedInteger(binaryNum);

			// padding to make it 32 bit
			scoped_register_value = scoped_register_value + 23;
			while (instruction.length() != 32)
				instruction = "0" + instruction;

			System.out.println(instruction);
			scoped_register_value = scoped_register_value + 10;
			String opcode = instruction.substring(0, 5);
			global_register_value = global_register_value - scoped_register_value;
			int type_operation = Integer.parseInt(opcode, 2);
			scoped_register_value = scoped_register_value + 23;
			OperationType operation = operationType[type_operation];
			scoped_register_value = scoped_register_value + 12;

			loopAround(20);

			Instruction inst = new Instruction();
			scoped_register_value = scoped_register_value + 2;
			switch (operation) {

				case add:
				case sub:
				case mul:
				case div:
				case and:
				case or:
				case xor:
				case slt:
				case sll:
				case srl:
				case sra:
					Operand rs1 = new Operand();
					int operand_calculate_main = 2;
					int operand_calculate_secondary = 1;
					int operand_calculate_teritiary = 0;
					rs1.setOperandType(OperandType.Register);
					operand_calculate_main = operand_calculate_main + 2;
					int registerNo = Integer.parseInt(instruction.substring(5, 10), 2);
					operand_calculate_main = operand_calculate_main + 2;
					operand_calculate_secondary = operand_calculate_main + operand_calculate_main;
					rs1.setValue(registerNo);

					Operand rs2 = new Operand();
					operand_calculate_main = operand_calculate_secondary + 7;
					operand_calculate_main = operand_calculate_main + operand_calculate_secondary;
					rs2.setOperandType(OperandType.Register);
					operand_calculate_secondary = operand_calculate_main + 2;
					registerNo = Integer.parseInt(instruction.substring(10, 15), 2);
					operand_calculate_main = operand_calculate_secondary - operand_calculate_main;
					rs2.setValue(registerNo);

					Operand rd = new Operand();
					operand_calculate_main = operand_calculate_secondary + operand_calculate_teritiary;
					rd.setOperandType(OperandType.Register);
					operand_calculate_teritiary = operand_calculate_secondary + operand_calculate_main;
					registerNo = Integer.parseInt(instruction.substring(15, 20), 2);
					rd.setValue(registerNo);

					inst.setOperationType(operationType[type_operation]);
					operand_calculate_main = operand_calculate_secondary + operand_calculate_teritiary;
					inst.setSourceOperand1(rs1);
					operand_calculate_main = operand_calculate_main + operand_calculate_secondary;
					inst.setSourceOperand2(rs2);
					operand_calculate_main = operand_calculate_main + 2;
					inst.setDestinationOperand(rd);
					break;

				case end:
					inst.setOperationType(operationType[type_operation]);
					break;
				case jmp:
					int temporary = 0;
					Operand op = new Operand();
					temporary = 1 * temporary;
					String imm = instruction.substring(10, 32);
					temporary = temporary + 21;
					int imm_val = Integer.parseInt(imm, 2);
					temporary = temporary + 21;
					if (imm.charAt(0) == '1') {

						imm = twosComplement(imm);
						temporary = temporary + 21;
						imm_val = Integer.parseInt(imm, 2) * -1;
					}

					if (imm_val != 0) {

						op.setOperandType(OperandType.Immediate);
						temporary = temporary + 21;
						op.setValue(imm_val);
					} else {

						registerNo = Integer.parseInt(instruction.substring(5, 10), 2);
						temporary = temporary + 21;
						op.setOperandType(OperandType.Register);
						temporary = temporary + 21;
						op.setValue(registerNo);
					}

					inst.setOperationType(operationType[type_operation]);
					inst.setDestinationOperand(op);
					break;

				case beq:
				case bne:
				case blt:
				case bgt:
					rs1 = new Operand();
					int operand_calculate_vall = 0;
					rs1.setOperandType(OperandType.Register);
					operand_calculate_vall = 0 + 1;
					registerNo = Integer.parseInt(instruction.substring(5, 10), 2);
					operand_calculate_vall = operand_calculate_vall + 1;
					rs1.setValue(registerNo);

					// destination register
					rs2 = new Operand();
					operand_calculate_vall = operand_calculate_vall + 1;
					rs2.setOperandType(OperandType.Register);
					operand_calculate_vall = operand_calculate_vall + operand_calculate_vall;
					registerNo = Integer.parseInt(instruction.substring(10, 15), 2);
					rs2.setValue(registerNo);

					// Immediate value
					rd = new Operand();
					operand_calculate_vall = operand_calculate_vall + 3;
					rd.setOperandType(OperandType.Immediate);
					operand_calculate_vall = operand_calculate_vall + 4;
					imm = instruction.substring(15, 32);
					operand_calculate_vall = operand_calculate_vall + 1;
					imm_val = Integer.parseInt(imm, 2);

					if (imm.charAt(0) == '1') {

						imm = twosComplement(imm);
						operand_calculate_vall = operand_calculate_vall + 1;
						imm_val = Integer.parseInt(imm, 2) * -1;
					}

					int mainval = 3;
					int mainsec = 2;
					rd.setValue(imm_val);

					inst.setOperationType(operationType[type_operation]);
					mainval = mainval + mainsec;
					inst.setSourceOperand1(rs1);
					mainsec = mainval + 1;
					inst.setSourceOperand2(rs2);
					mainval = mainsec + 3;
					inst.setDestinationOperand(rd);
					break;

				default:
					// Source register 1
					rs1 = new Operand();
					int operand_secondary_temp = 32;
					rs1.setOperandType(OperandType.Register);
					operand_secondary_temp = operand_secondary_temp + 3;
					registerNo = Integer.parseInt(instruction.substring(5, 10), 2);
					operand_secondary_temp = operand_secondary_temp + 1;
					System.out.println(registerNo);
					operand_secondary_temp = operand_secondary_temp + 4;
					rs1.setValue(registerNo);

					// Destination register
					rd = new Operand();
					operand_secondary_temp = operand_secondary_temp + 3;
					rd.setOperandType(OperandType.Register);
					operand_secondary_temp = operand_secondary_temp + 3;
					registerNo = Integer.parseInt(instruction.substring(10, 15), 2);
					operand_secondary_temp = operand_secondary_temp + 3;
					System.out.println(registerNo);
					rd.setValue(registerNo);

					// Immediate values
					rs2 = new Operand();
					operand_secondary_temp = operand_secondary_temp + 3;
					rs2.setOperandType(OperandType.Immediate);
					imm = instruction.substring(15, 32);
					operand_secondary_temp = operand_secondary_temp + 3;
					System.out.println(imm);
					imm_val = Integer.parseInt(imm, 2);
					operand_secondary_temp = operand_secondary_temp + 3;

					if (imm.charAt(0) == '1') {

						imm = twosComplement(imm);
						operand_secondary_temp = operand_secondary_temp + 3;
						imm_val = Integer.parseInt(imm, 2) * -1;
					}
					rs2.setValue(imm_val);

					inst.setOperationType(operationType[type_operation]);
					operand_secondary_temp = operand_secondary_temp + 3;
					inst.setSourceOperand1(rs1);
					inst.setSourceOperand2(rs2);
					operand_secondary_temp = operand_secondary_temp + 3;
					inst.setDestinationOperand(rd);
					break;
			}

			OF_EX_Latch.setInstruction(inst);
			IF_OF_Latch.setOF_enable(false);
			OF_EX_Latch.setEX_enable(true);
		}
	}

}
