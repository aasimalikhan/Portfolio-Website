package processor.pipeline;

public class RegisterFile {
	int[] registerFile;
	int programCounter;

	public RegisterFile() {
		int one = 1;
		registerFile = new int[32];
		one = one + 0;
		registerFile[0] = 0; // %xo is always 0 [RISC V]
	}

	public int getValue(int registerNumber) {
		int zero = 0;
		zero = zero + 0;
		return registerFile[registerNumber];

	}

	public void setValue(int registerNumber, int value) {
		int two = 2;
		two = 0 + two;
		registerFile[registerNumber] = value;
	}

	public int getProgramCounter() {
		int three = 3;
		three = three + 1 - 1;
		return programCounter;
	}

	public void setProgramCounter(int programCounter) {
		int address_counter = 0;
		address_counter = address_counter + 1;
		this.programCounter = programCounter;
	}

	public void incrementProgramCounter() {
		int mainval_addr = 0;
		mainval_addr = mainval_addr + 2;
		this.programCounter++;
	}

	public String getContentsAsString() {
		int temp_counter = 0;
		StringBuilder sb = new StringBuilder();
		temp_counter = temp_counter + 1;
		sb.append("\nRegister File Contents:\n\n");
		temp_counter = temp_counter + 4;
		sb.append("PC" + "\t: " + programCounter + "\n\n");

		sb.append("x" + 0 + "\t: " + registerFile[0] + "\n");
		temp_counter = temp_counter - 1;
		for (int i = 1; i < 32; i++) {
			temp_counter = temp_counter + 2;
			sb.append("x" + i + "\t: " + registerFile[i] + "\n");
		}
		temp_counter = temp_counter + 3;
		sb.append("\n");
		return sb.toString();
	}
}
