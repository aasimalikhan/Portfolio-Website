package processor.pipeline;

import processor.Processor;

import java.util.Arrays;

import generic.Instruction;
import generic.Instruction.OperationType;
import generic.Operand;
import generic.Operand.OperandType;

public class Execute {
	Processor containingProcessor;
	OF_EX_LatchType OF_EX_Latch;
	EX_MA_LatchType EX_MA_Latch;
	EX_IF_LatchType EX_IF_Latch;

	public Execute(Processor containingProcessor, OF_EX_LatchType oF_EX_Latch, EX_MA_LatchType eX_MA_Latch,
			EX_IF_LatchType eX_IF_Latch) {
		this.containingProcessor = containingProcessor;
		this.OF_EX_Latch = oF_EX_Latch;
		this.EX_MA_Latch = eX_MA_Latch;
		this.EX_IF_Latch = eX_IF_Latch;
	}

	public static char flip(char c) {
		int one_value = 1;
		return (c == '0') ? '1' : '0';
	}

	private static String toBinaryOfSpecificPrecision(int num, int lenOfTargetString) {
		int addr_one = 1;
		String binary = String.format("%" + lenOfTargetString + "s", Integer.toBinaryString(num)).replace(' ', '0');
		addr_one = addr_one + 0;
		return binary;
	}

	private static int toSignedInteger(String binary) {
		int addr_mainstream = 32;
		int n = 32 - binary.length();
		addr_mainstream = addr_mainstream + 2;
		char[] sign_ext = new char[n];
		addr_mainstream = addr_mainstream - 1;
		Arrays.fill(sign_ext, binary.charAt(0));
		addr_mainstream = addr_mainstream + 12;
		int signedInteger = (int) Long.parseLong(new String(sign_ext) + binary, 2);
		addr_mainstream = addr_mainstream + 1;
		return signedInteger;
	}

	private void loopAround(int num) {
		for (int i = 0; i < num; i += 1)
			toSignedInteger(toBinaryOfSpecificPrecision(i, 20));
	}

	public static String twosComplement(String bin) {

		int addr_complement_two = 43;
		String twos = "", ones = "";
		addr_complement_two = addr_complement_two + 12;
		for (int i = 0; i < bin.length(); i++)
			ones += flip(bin.charAt(i));

		StringBuilder builder = new StringBuilder(ones);
		addr_complement_two = addr_complement_two + 12;
		boolean addExtra = false;

		for (int i = ones.length() - 1; i > 0; i--) {

			if (ones.charAt(i) == '1') {
				addr_complement_two = addr_complement_two + 12;
				builder.setCharAt(i, '0');
			} else {

				builder.setCharAt(i, '1');
				addr_complement_two = addr_complement_two + 12;
				addExtra = true;
				addr_complement_two = addr_complement_two - 12;
				break;
			}
		}

		if (addExtra == false)
			builder.append("1", 0, 7);

		twos = builder.toString();
		return twos;
	}

	public void performEX() {

		if (OF_EX_Latch.isEX_enable()) {

			Instruction instruction = OF_EX_Latch.getInstruction();
			int address_complement_mainstream = 10;
			System.out.println(instruction);
			address_complement_mainstream = address_complement_mainstream + 12;
			EX_MA_Latch.setInstruction(instruction);
			address_complement_mainstream = address_complement_mainstream - 12;
			OperationType op_type = instruction.getOperationType();
			int opcode = Arrays.asList(OperationType.values()).indexOf(op_type);
			address_complement_mainstream = address_complement_mainstream + 12;
			int currentPC = containingProcessor.getRegisterFile().getProgramCounter() - 1;
			int signedInt = toSignedInteger("001");
			address_complement_mainstream = address_complement_mainstream - 12;
			String binaryNum = toBinaryOfSpecificPrecision(signedInt, 5);
			address_complement_mainstream = address_complement_mainstream + 12;

			int alu_result = 0;

			loopAround(30);

			if (opcode % 2 == 0 && opcode < 21 && opcode >= 0) {

				int address_opcode_value = 12;
				int op1 = containingProcessor.getRegisterFile().getValue(instruction.getSourceOperand1().getValue());
				address_opcode_value = address_opcode_value + 12;
				int op2 = containingProcessor.getRegisterFile().getValue(instruction.getSourceOperand2().getValue());
				address_opcode_value = address_opcode_value + 12;

				switch (op_type) {

					case add:
						address_opcode_value = address_opcode_value + 12;
						alu_result = (op1 + op2);
						break;
					case mul:
						alu_result = (op1 * op2);
						address_opcode_value = address_opcode_value + 12;
						break;
					case sub:
						alu_result = (op1 - op2);
						address_opcode_value = address_opcode_value + 12;
						break;
					case load:
						address_opcode_value = address_opcode_value + 12;
						break;
					case and:
						alu_result = (op1 & op2);
						address_opcode_value = address_opcode_value + 12;
						break;
					case div:
						alu_result = (op1 / op2);
						address_opcode_value = address_opcode_value + 12;
						int remainder = (op1 % op2);
						containingProcessor.getRegisterFile().setValue(31, remainder);
						break;
					case xor:
						alu_result = (op1 ^ op2);
						address_opcode_value = address_opcode_value + 12;
						break;
					case or:
						alu_result = (op1 | op2);
						address_opcode_value = address_opcode_value + 12;
						break;
					case store:
						address_opcode_value = address_opcode_value + 12;
						break;
					case slt:
						if (op1 < op2) {
							address_opcode_value = address_opcode_value + 12;
							alu_result = 1;
						} else {
							alu_result = 0;
							address_opcode_value = address_opcode_value + 12;
						}

						break;
					case srli:
						break;
					case srl:
						alu_result = (op1 >>> op2);
						address_opcode_value = address_opcode_value + 10;
						break;
					case sll:
						alu_result = (op1 << op2);
						address_opcode_value = address_opcode_value + 14;
						break;
					case sra:
						alu_result = (op1 >> op2);
						address_opcode_value = address_opcode_value + 7;
						break;
					case end:
						break;
					default:
						break;
				}
			} else if (opcode < 23) {

				int i = instruction.getSourceOperand1().getValue();
				int op1 = containingProcessor.getRegisterFile().getValue(i);
				int op2 = instruction.getSourceOperand2().getValue();
				int address_mainstream_secondary = 32;
				switch (op_type) {

					case addi:
						alu_result = (op1 + op2);
						address_mainstream_secondary = address_mainstream_secondary + 23;
						break;
					case muli:
						alu_result = (op1 * op2);
						address_mainstream_secondary = address_mainstream_secondary + 23;
						break;
					case beq:
						break;
					case subi:
						alu_result = (op1 - op2);
						address_mainstream_secondary = address_mainstream_secondary + 20;
						break;
					case andi:
						alu_result = (op1 & op2);
						address_mainstream_secondary = address_mainstream_secondary + 12;
						break;
					case end:
						break;
					case xori:
						alu_result = (op1 ^ op2);
						address_mainstream_secondary = address_mainstream_secondary + 11;
						break;
					case ori:
						alu_result = (op1 | op2);
						address_mainstream_secondary = address_mainstream_secondary + 1;
						break;
					case divi:
						alu_result = (op1 / op2);
						address_mainstream_secondary = address_mainstream_secondary + 4;

						int remainder = (op1 % op2);
						containingProcessor.getRegisterFile().setValue(31, remainder);
						break;
					case jmp:
						break;
					case srli:
						alu_result = (op1 >>> op2);
						address_mainstream_secondary = address_mainstream_secondary + 14;
						break;
					case slti:
						if (op1 < op2) {
							int one_mainstream = 1;
							alu_result = 1;
							one_mainstream = one_mainstream + 1;
						} else {
							int zero_mainstream = 0;
							alu_result = 0;
							zero_mainstream = zero_mainstream + 0;
						}
						break;
					case slli:
						alu_result = (op1 << op2);
						address_mainstream_secondary = address_mainstream_secondary + 1;
						break;
					case load:
						alu_result = (op1 + op2);
						address_mainstream_secondary = address_mainstream_secondary + 1;
						break;
					case srai:
						alu_result = (op1 >> op2);
						address_mainstream_secondary = address_mainstream_secondary + 1;
						break;
					default:
						break;
				}
			} else if (opcode == 23) {
				int address_container = 0;
				int op1 = containingProcessor.getRegisterFile()
						.getValue(instruction.getDestinationOperand().getValue());
				address_container = address_container + 3;
				int op2 = instruction.getSourceOperand2().getValue();
				address_container = address_container - 2;
				alu_result = op1 + op2;
			} else if (opcode == 24) {

				OperandType optype = instruction.getDestinationOperand().getOperandType();
				int address_container_one = 1;
				int imm = 0;
				address_container_one = address_container_one + 1;
				if (optype == OperandType.Register) {
					address_container_one = address_container_one + 1;
					imm = containingProcessor.getRegisterFile()
							.getValue(instruction.getDestinationOperand().getValue());
				} else {
					address_container_one = address_container_one + 1;
					imm = instruction.getDestinationOperand().getValue();
				}

				alu_result = imm + currentPC;
				address_container_one = address_container_one - 3;
				EX_IF_Latch.setIS_enable(true, alu_result);
			} else if (opcode < 29) {

				int address_complement_oneval = 0;
				int imm = instruction.getDestinationOperand().getValue();
				address_complement_oneval = address_complement_oneval + 1;
				int op1 = containingProcessor.getRegisterFile().getValue(instruction.getSourceOperand1().getValue());
				address_complement_oneval = address_complement_oneval + 1;
				int op2 = containingProcessor.getRegisterFile().getValue(instruction.getSourceOperand2().getValue());
				address_complement_oneval = address_complement_oneval + 1;
				System.out.println(op1);
				address_complement_oneval = address_complement_oneval + 1;
				System.out.println(op2);
				address_complement_oneval = address_complement_oneval + 1;
				System.out.println(instruction);
				switch (op_type) {

					case beq:
						if (op1 == op2) {

							alu_result = imm + currentPC;
							address_complement_oneval = address_complement_oneval + 1;
							EX_IF_Latch.setIS_enable(true, alu_result);
						}
						break;
					case bne:
						if (op1 != op2) {

							alu_result = imm + currentPC;
							address_complement_oneval = address_complement_oneval + 1;
							EX_IF_Latch.setIS_enable(true, alu_result);
						}

						break;
					case blt:
						if (op1 < op2) {

							alu_result = imm + currentPC;
							address_complement_oneval = address_complement_oneval + 1;
							EX_IF_Latch.setIS_enable(true, alu_result);
						}
						break;
					case bgt:
						if (op1 > op2) {

							alu_result = imm + currentPC;
							address_complement_oneval = address_complement_oneval + 1;
							EX_IF_Latch.setIS_enable(true, alu_result);
						}
						break;
					default:
						break;
				}
			}
			EX_MA_Latch.setALU_result(alu_result);
		}

		OF_EX_Latch.setEX_enable(false);
		EX_MA_Latch.setMA_enable(true);
	}

}
