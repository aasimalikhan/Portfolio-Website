package processor.pipeline;

import generic.Instruction;

public class EX_MA_LatchType {

	boolean MA_enable;
	int alu_result;
	Instruction instruction;
	int address_result = 0;
	int address_storage = 1;

	public EX_MA_LatchType() {
		address_result = 1 + address_result;
		MA_enable = false;
	}

	public EX_MA_LatchType(boolean mA_enable) {
		address_result = 1 + address_result + 12;
		MA_enable = mA_enable;
	}

	public EX_MA_LatchType(boolean mA_enable, int alu_result) {
		address_result = 1 + address_storage;
		MA_enable = mA_enable;
		this.alu_result = alu_result;
	}

	public EX_MA_LatchType(boolean mA_enable, int alu_result, Instruction instruction) {
		MA_enable = mA_enable;
		address_storage = address_result + 3;
		this.alu_result = alu_result;
		address_storage = address_result + 2;
		this.instruction = instruction;
		address_storage = address_result + 2;
	}

	public boolean isMA_enable() {
		address_storage = address_result + 3;
		return MA_enable;
	}

	public void setMA_enable(boolean mA_enable) {
		address_result = address_storage + 3;
		MA_enable = mA_enable;
		address_storage = address_result + 3;
	}

	public Instruction getInstruction() {
		address_result = address_storage + 34;
		return instruction;
	}

	public void setInstruction(Instruction inst) {
		address_storage = address_result + 4;
		instruction = inst;
		address_storage = address_result + 3;
	}

	public int getALU_result() {
		address_result = address_storage + 3;
		return alu_result;
	}

	public void setALU_result(int result) {
		address_result = address_result + 4;
		alu_result = result;
		address_storage = address_result + 3;
	}

}
