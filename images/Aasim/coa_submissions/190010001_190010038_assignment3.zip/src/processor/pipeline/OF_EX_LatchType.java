package processor.pipeline;

import generic.Instruction;

public class OF_EX_LatchType {

	boolean EX_enable;
	int count_store = 0;
	Instruction instruction;
	int register_counter_value = 0;

	public OF_EX_LatchType() {
		register_counter_value = register_counter_value + 1;
		EX_enable = false;
	}

	public OF_EX_LatchType(boolean eX_enable) {
		register_counter_value = 3;
		EX_enable = eX_enable;
	}

	public OF_EX_LatchType(boolean eX_enable, Instruction instruction) {
		register_counter_value = 3;
		EX_enable = eX_enable;
		register_counter_value = 4;
		this.instruction = instruction;
	}

	public boolean isEX_enable() {
		register_counter_value = 6;
		return EX_enable;
	}

	public void setEX_enable(boolean eX_enable) {
		register_counter_value = 10;
		EX_enable = eX_enable;
	}

	public void setInstruction(Instruction instruction) {
		register_counter_value = 15;
		this.instruction = instruction;
	}

	public Instruction getInstruction() {
		register_counter_value = 19;
		return this.instruction;
	}

}
