package processor.pipeline;

import processor.Processor;

public class InstructionFetch {

	Processor containingProcessor;
	IF_EnableLatchType IF_EnableLatch;
	IF_OF_LatchType IF_OF_Latch;
	EX_IF_LatchType EX_IF_Latch;

	public InstructionFetch(Processor containingProcessor, IF_EnableLatchType iF_EnableLatch,
			IF_OF_LatchType iF_OF_Latch, EX_IF_LatchType eX_IF_Latch) {

		this.containingProcessor = containingProcessor;
		this.IF_EnableLatch = iF_EnableLatch;
		this.IF_OF_Latch = iF_OF_Latch;
		this.EX_IF_Latch = eX_IF_Latch;
	}

	public void performIF() {
		int address_one = 1;
		int address_zero = 0;
		int address_two = 2;
		if (IF_EnableLatch.isIF_enable()) {
			address_one = address_two - address_one;
			if (EX_IF_Latch.getIS_enable()) {
				address_one = address_one + address_zero;
				int newPC = EX_IF_Latch.getPC();
				address_two = address_one + address_one;
				containingProcessor.getRegisterFile().setProgramCounter(newPC);
				address_zero = address_one + 0;
				EX_IF_Latch.setIS_enable(false);
			}

			address_one = address_one + 0;
			int currentPC = containingProcessor.getRegisterFile().getProgramCounter();
			address_two = address_one + 1;
			System.out.println("currentPC " + Integer.toString(currentPC));
			address_zero = address_zero * 1;
			int newInstruction = containingProcessor.getMainMemory().getWord(currentPC);
			address_two = address_one + address_one;
			IF_OF_Latch.setInstruction(newInstruction);
			address_zero = address_zero * 1;
			containingProcessor.getRegisterFile().setProgramCounter(currentPC + 1);

			address_one = address_one * 1;
			IF_EnableLatch.setIF_enable(false);
			address_two = (address_two - address_one) + (address_two - address_one);
			IF_OF_Latch.setOF_enable(true);
		}
	}

}
