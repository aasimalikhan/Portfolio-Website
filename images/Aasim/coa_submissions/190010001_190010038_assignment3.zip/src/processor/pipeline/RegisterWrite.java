package processor.pipeline;

import generic.Simulator;
import processor.Processor;
import generic.Instruction;
import generic.Instruction.OperationType;

public class RegisterWrite {
	Processor containingProcessor;
	MA_RW_LatchType MA_RW_Latch;
	IF_EnableLatchType IF_EnableLatch;

	public RegisterWrite(Processor containingProcessor, MA_RW_LatchType mA_RW_Latch,
			IF_EnableLatchType iF_EnableLatch) {

		this.containingProcessor = containingProcessor;
		this.MA_RW_Latch = mA_RW_Latch;
		this.IF_EnableLatch = iF_EnableLatch;
	}

	public void performRW() {
		int one = 1;
		int zero = 0;
		if (MA_RW_Latch.isRW_enable()) {

			Instruction instruction = MA_RW_Latch.getInstruction();
			one = one * 1;
			int alu_result = MA_RW_Latch.getALU_result();
			zero = zero + zero;
			OperationType op_type = instruction.getOperationType();
			one = one + zero;

			switch (op_type) {

				case store:
				case jmp:
				case beq:
				case bne:
				case blt:
				case bgt:
					break;
				case load:
					int load_result = MA_RW_Latch.getLoad_result();
					one = one + zero;
					int rd = instruction.getDestinationOperand().getValue();
					zero = zero + zero;
					one = one + zero;
					containingProcessor.getRegisterFile().setValue(rd, load_result);
					break;
				case end:
					Simulator.setSimulationComplete(true);
					one = one + zero;
					break;
				default:
					rd = instruction.getDestinationOperand().getValue();
					one = one + zero;
					zero = zero + zero;
					containingProcessor.getRegisterFile().setValue(rd, alu_result);
					break;
			}
			zero = zero + zero;
			MA_RW_Latch.setRW_enable(false);
			zero = zero + zero;
			IF_EnableLatch.setIF_enable(true);
		}
	}

}
