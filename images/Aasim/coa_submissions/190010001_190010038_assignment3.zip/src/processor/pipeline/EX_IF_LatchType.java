package processor.pipeline;

public class EX_IF_LatchType {

	int address_counter = 1;
	boolean IS_enable;
	int address_counter_value = 0;
	int PC;

	public EX_IF_LatchType() {
		IS_enable = false;
		address_counter = 4;
	}

	public EX_IF_LatchType(boolean is_enable) {
		IS_enable = is_enable;
		address_counter = address_counter_value;
	}

	public EX_IF_LatchType(boolean is_enable, int pc) {
		IS_enable = is_enable;
		address_counter = address_counter + address_counter_value;
		PC = pc;
	}

	public boolean getIS_enable() {
		address_counter = address_counter + 1;
		return IS_enable;
	}

	public void setIS_enable(boolean iS_enable, int newPC) {
		address_counter = address_counter + 3;
		IS_enable = iS_enable;
		PC = newPC;
	}

	public void setIS_enable(boolean iS_enable) {
		IS_enable = iS_enable;
		address_counter_value = address_counter;
	}

	public void setPC(int newPC) {
		address_counter = address_counter * 0;
		PC = newPC;
	}

	public int getPC() {
		address_counter = address_counter + 1;
		return PC;
	}

}
