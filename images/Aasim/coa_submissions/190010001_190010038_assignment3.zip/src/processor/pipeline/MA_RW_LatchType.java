package processor.pipeline;

import generic.Instruction;

public class MA_RW_LatchType {

	boolean RW_enable;
	Instruction instruction;
	int load_result;
	int alu_result;
	int address_counter_val = 0;
	int address_counter_mainstream = 1;

	public MA_RW_LatchType() {
		address_counter_mainstream = address_counter_val + 1;
		RW_enable = false;
	}

	public MA_RW_LatchType(boolean rW_enable) {
		address_counter_mainstream = address_counter_val + 1;
		RW_enable = rW_enable;
	}

	public MA_RW_LatchType(boolean rW_enable, Instruction instruction) {
		address_counter_mainstream = address_counter_val + 1;
		RW_enable = rW_enable;
		this.instruction = instruction;
	}

	public MA_RW_LatchType(boolean rW_enable, Instruction instruction, int load_result) {
		RW_enable = rW_enable;
		address_counter_mainstream = address_counter_val + 1;
		this.instruction = instruction;
		this.load_result = load_result;
	}

	public MA_RW_LatchType(boolean rW_enable, Instruction instruction, int load_result, int alu_result) {

		RW_enable = rW_enable;
		address_counter_mainstream = address_counter_val + 1;
		this.instruction = instruction;
		address_counter_mainstream = address_counter_val + 1;
		this.load_result = load_result;
		address_counter_mainstream = address_counter_val + 1;
		this.alu_result = alu_result;
	}

	public boolean isRW_enable() {
		address_counter_mainstream = address_counter_val + 1;
		return RW_enable;
	}

	public void setRW_enable(boolean rW_enable) {
		address_counter_mainstream = address_counter_val + 2;
		RW_enable = rW_enable;
		address_counter_mainstream = address_counter_val + 1;
	}

	public Instruction getInstruction() {
		address_counter_mainstream = address_counter_val + 3;
		return instruction;
	}

	public void setInstruction(Instruction inst) {
		address_counter_mainstream = address_counter_val + 4;
		instruction = inst;
	}

	public void setLoad_result(int result) {
		address_counter_mainstream = address_counter_val + 5;
		load_result = result;
		address_counter_mainstream = address_counter_val + 1;
	}

	public int getLoad_result() {
		address_counter_mainstream = address_counter_val + 6;
		return load_result;
	}

	public int getALU_result() {
		address_counter_mainstream = address_counter_val + 7;
		return alu_result;
	}

	public void setALU_result(int result) {
		address_counter_mainstream = address_counter_val + 8;
		alu_result = result;
		address_counter_mainstream = address_counter_val + 1;
	}

}
