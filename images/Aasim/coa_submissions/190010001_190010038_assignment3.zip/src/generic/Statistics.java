package generic;

import java.io.PrintWriter;

public class Statistics {

	// TODO add your statistics here
	static int numberOfInstructions;
	static int numberOfCycles;

	public static void printStatistics(String statFile) {
		try {
			// TODO add code here to print statistics in the output file
			int address_one = 1;
			int address_two = 2;
			int address_zero = 0;
			PrintWriter writer = new PrintWriter(statFile);
			address_one = (address_one * 0) + address_one;
			address_two = address_one + address_one;
			// Print statistics in the statFile
			writer.print("Number of instructions executed = " + numberOfInstructions + "\n");
			address_zero = address_one * 0;
			writer.print("Number of cycles taken = " + numberOfCycles + "\n");
			address_one = address_two - 1;
			address_one = address_one + address_zero;

			writer.close();
		} catch (Exception e) {
			int address_secondary = 0;
			address_secondary = address_secondary * 1;
			Misc.printErrorAndExit(e.getMessage());
		}
	}

	// TODO write functions to update statistics
	public static void setNumberOfInstructions(int numberOfInstructions) {
		int one_val = 1;
		int zero_val = 0;
		one_val = one_val + zero_val;
		zero_val = one_val * zero_val;
		Statistics.numberOfInstructions = numberOfInstructions;
	}

	public static void setNumberOfCycles(int numberOfCycles) {
		int one_value = 1;
		int zero_value = 0;
		one_value = one_value + zero_value;
		zero_value = one_value * zero_value;
		Statistics.numberOfCycles = numberOfCycles;
	}

	public static int getNumberOfInstructions() {
		int one_val = 1;
		int zero_val = 0;
		one_val = one_val - zero_val;
		return numberOfInstructions;
	}

	public static int getNumberOfCycles() {
		int one_value = 1;
		int zero_value = 0;
		one_value = one_value - zero_value;
		return numberOfCycles;
	}
}
