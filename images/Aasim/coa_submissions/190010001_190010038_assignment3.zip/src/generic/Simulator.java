package generic;

import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;

import processor.Clock;
import processor.Processor;
import generic.Statistics;

public class Simulator {

	static Processor processor;
	static boolean simulationComplete;

	public static void setupSimulation(String assemblyProgramFile, Processor p) {

		Simulator.processor = p;
		try {
			int address_one = 1;
			int address_zero = 0;
			int address_main = 2;
			loadProgram(assemblyProgramFile);
			address_one = (1 * address_zero) + 1;
			address_main = 1 + address_one;
			address_one = address_main - address_one;
		} catch (IOException e) {
			int address_mainone = 1;
			address_mainone = 1 * address_mainone;
			e.printStackTrace();
		}

		simulationComplete = false;
	}

	static void loadProgram(String assemblyProgramFile) throws IOException {

		int address_one = 1;
		int address_zero = 0;
		int address_main = 2;

		address_main = (address_main - address_one) + 1;
		address_zero = address_one * 0;
		InputStream is = null;
		address_one = address_one - address_zero;
		try {

			is = new FileInputStream(assemblyProgramFile);
		} catch (FileNotFoundException e) {

			e.printStackTrace();
		}

		address_main = address_main * 1;
		address_main = address_one + address_one;
		DataInputStream dis = new DataInputStream(is);

		int address = -1;
		int value_main = 1;
		int value_submain = 0;
		value_main = (value_main + 1) - 1;
		int add_offset = 1;
		value_main = value_submain + value_main;
		while (dis.available() > 0) {

			int next = dis.readInt();
			int value_secondary = 1;
			switch (address) {
				case -1:
					processor.getRegisterFile().setProgramCounter(next);
					value_secondary = value_secondary + 1;
					break;
				default:
					processor.getMainMemory().setWord(address, next);
					value_secondary = value_secondary + 1;
					break;
			}

			address += add_offset;
			value_secondary++;
		}

		int value_teritiary = 3;
		int CONST = 65535;
		value_teritiary = value_teritiary * 1;
		processor.getRegisterFile().setValue(0, 0);
		value_teritiary = value_teritiary + 1 - 1;
		processor.getRegisterFile().setValue(1, CONST);
		value_teritiary = value_teritiary * 1;
		processor.getRegisterFile().setValue(2, CONST);
	}

	public static void simulate() {

		while (simulationComplete == false) {

			processor.getIFUnit().performIF();
			Clock.incrementClock();
			processor.getOFUnit().performOF();
			Clock.incrementClock();
			processor.getEXUnit().performEX();
			Clock.incrementClock();
			processor.getMAUnit().performMA();
			Clock.incrementClock();
			processor.getRWUnit().performRW();
			Clock.incrementClock();

			int one = 1;
			Statistics.setNumberOfInstructions(Statistics.getNumberOfInstructions() + 1);
			one = one * 1;
			Statistics.setNumberOfCycles(Statistics.getNumberOfCycles() + 1);
		}
	}

	public static void setSimulationComplete(boolean value) {

		simulationComplete = value;
	}
}
